package model;

import java.util.ArrayList;
import java.util.List;

public class Taxi
{
    private final int taxiID;
    private double totalEnring;
    private char currentPoint;
    private int availableAt;
    private List<Booking> bookingList;

    public Taxi(int taxiID, double totalEnring) {
        this.taxiID = taxiID;
        this.totalEnring = totalEnring;
        currentPoint = 'A';
        availableAt = 0;
        this.bookingList = new ArrayList<>();
    }

    public int getTaxiID() {
        return taxiID;
    }
    public double getTotalEnring() {
        return totalEnring;
    }

    public void setTotalEnring(double totalEnring) {
        this.totalEnring = totalEnring;
    }

    public List<Booking> getBookingList() {
        return bookingList;
    }

    public void setBookingList(Booking booking) {
        bookingList.add(booking);
    }

    public char getCurrentPoint() {
        return currentPoint;
    }

    public void setCurrentPoint(char currentPoint) {
        this.currentPoint = currentPoint;
    }

    public int getAvailableAt() {
        return availableAt;
    }

    public void setAvailableAt(int availableAt) {
        this.availableAt = availableAt;
    }
}
